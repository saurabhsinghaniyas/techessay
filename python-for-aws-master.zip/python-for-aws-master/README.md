# Python for AWS with examples and lab practice :metal: :fire:

**Various scenario based examples to use AWS SDK for Python i.e. Boto3**


> # I will update this page soon. Stay Tuned!
